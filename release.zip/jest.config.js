module.exports = {
  testEnvironment: 'node',
  roots: ['<rootDir>/test'],
};
