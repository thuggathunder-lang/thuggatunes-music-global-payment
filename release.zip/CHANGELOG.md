# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]

- Add CLI options and logging
- Add Jest tests and CI
- Add Dockerfile and release scripts
